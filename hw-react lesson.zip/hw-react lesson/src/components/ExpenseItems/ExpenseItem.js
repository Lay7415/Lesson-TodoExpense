import React from 'react';
import './ExpenseItem.css';
import ExpenseDate from './Date/ExpenseDate';
import ExpensesAmount from './Amount/ExpensesAmount';

function ExpenseItem(props) {
    const expenseDate = props.date;
    const expenseTitle = props.title;
    const expenseAmount = props.amount;

    return (
        <div className='expense-item'>
            <ExpenseDate date = {expenseDate}/>
            <ExpensesAmount 
            title={expenseTitle}
            amount={expenseAmount}
            />
        </div>
    );
}

export default ExpenseItem;